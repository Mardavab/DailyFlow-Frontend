import { createContext } from "react";

export const InvoiceContext = createContext();