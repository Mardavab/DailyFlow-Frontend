import { createContext } from "react";
export const SalesContext = createContext();